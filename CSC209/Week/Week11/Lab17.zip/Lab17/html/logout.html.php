<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="../css/logoutPage.css">
        <script src="../js/userFunctions.js"></script>
    </head>
    <body>
        <h1>Goodbye!</h1>
        <form>
            <input id="return-login-button" type="button" value="Return To Log In Page" onclick="openLogInPage()">
        </form>
    </body>
</html>